'use client'

import { useCallback } from 'react'
import type { ChangeEvent } from 'react'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { SidebarFilters, ConferenceCard } from '@/components/ui'
import type { FilterState } from '@/components/ui'
import type { Conferencia } from '@/types/database'

type SortOrder = 'reciente' | 'antiguo' | 'titulo'

type ArchivoPageClientProps = {
  conferencias: Conferencia[]
  totalResults: number
  page: number
  pageSize: number
  initialFilters: FilterState
  initialSort: SortOrder
}

function setNullableParam(
  params: URLSearchParams,
  key: string,
  value: string | null
): void {
  if (value) {
    params.set(key, value)
    return
  }
  params.delete(key)
}

function setArrayParam(
  params: URLSearchParams,
  key: string,
  values: string[]
): void {
  params.delete(key)
  for (const value of values) {
    if (value) {
      params.append(key, value)
    }
  }
}

export default function ArchivoPageClient({
  conferencias,
  totalResults,
  page,
  pageSize,
  initialFilters,
  initialSort,
}: Readonly<ArchivoPageClientProps>) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const updateRoute = useCallback(
    (nextFilters: FilterState, nextSort: SortOrder) => {
      const params = new URLSearchParams(searchParams.toString())

      params.set('page', '1')
      params.set('sort', nextSort)

      setNullableParam(params, 'periodo', nextFilters.periodo)
      setNullableParam(params, 'libroBiblico', nextFilters.libroBiblico)
      setArrayParam(params, 'formatos', nextFilters.formatos)
      setArrayParam(params, 'temas', nextFilters.temas)

      const query = params.toString()
      const nextUrl = query ? `${pathname}?${query}` : pathname

      router.replace(nextUrl, { scroll: false })
    },
    [pathname, router, searchParams]
  )

  const handleFiltersChange = useCallback(
    (nextFilters: FilterState) => {
      updateRoute(nextFilters, initialSort)
    },
    [initialSort, updateRoute]
  )

  const handleSortChange = useCallback(
    (event: ChangeEvent<HTMLSelectElement>) => {
      updateRoute(initialFilters, event.target.value as SortOrder)
    },
    [initialFilters, updateRoute]
  )

  const resultStart =
    conferencias.length === 0 ? 0 : (page - 1) * pageSize + 1
  const resultEnd =
    conferencias.length === 0
      ? 0
      : resultStart + conferencias.length - 1

  return (
    <div
      className="min-h-screen"
      style={{ background: 'var(--color-bg-primary)' }}
    >
      <div className="mx-auto max-w-7xl px-6 pt-10 pb-6">
        <h1
          className="text-3xl md:text-4xl font-extrabold tracking-tight"
          style={{ color: 'var(--color-text-primary)' }}
        >
          Archivo Cronológico
        </h1>

        <p
          className="mt-2 text-sm"
          style={{ color: 'var(--color-text-muted)' }}
        >
          Explora el archivo completo de conferencias espirituales desde
          1978 hasta la actualidad.
        </p>
      </div>

      <div className="mx-auto max-w-7xl px-6 pb-20">
        <div className="flex flex-col gap-6 lg:flex-row">
          <SidebarFilters
            filters={initialFilters}
            onFiltersChange={handleFiltersChange}
          />

          <div className="min-w-0 flex-1">
            <div className="mb-6 flex items-center justify-between">
              <p
                className="text-sm"
                style={{ color: 'var(--color-text-muted)' }}
              >
                Mostrando{' '}
                <span style={{ color: 'var(--color-gold)' }}>
                  {resultStart}-{resultEnd}
                </span>{' '}
                de{' '}
                <span style={{ color: 'var(--color-gold)' }}>
                  {totalResults}
                </span>{' '}
                resultados
              </p>

              <select
                value={initialSort}
                onChange={handleSortChange}
                className="cursor-pointer rounded-lg px-3 py-2 text-xs font-medium outline-none"
                style={{
                  background: 'rgba(226, 184, 87, 0.05)',
                  border: '1px solid var(--color-border)',
                  color: 'var(--color-text-secondary)',
                }}
                aria-label="Ordenar conferencias"
              >
                <option value="reciente">
                  Ordenar por: Más reciente
                </option>
                <option value="antiguo">Más antiguo</option>
                <option value="titulo">Título A-Z</option>
              </select>
            </div>

            {conferencias.length === 0 ? (
              <div
                className="rounded-2xl border p-6"
                style={{
                  background: 'rgba(255, 255, 255, 0.03)',
                  borderColor: 'var(--color-border)',
                  color: 'var(--color-text-muted)',
                }}
              >
                No se encontraron conferencias con los filtros
                actuales.
              </div>
            ) : (
              <div className="stagger-children grid gap-5 sm:grid-cols-2">
                {conferencias.map((conf, index) => (
                  <ConferenceCard
                    key={conf.id}
                    conferencia={conf}
                    index={index}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
