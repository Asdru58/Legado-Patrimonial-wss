import ArchivoPageClient from './ArchivoPageClient'
import { getArchivoCronologicoPage } from '@/services/conferences'
import type { FilterState } from '@/components/ui'

const PAGE_SIZE = 20

type SortOrder = 'reciente' | 'antiguo' | 'titulo'

type ArchivoPageProps = {
  searchParams: Promise<{
    page?: string
    sort?: string
    periodo?: string
    formatos?: string | string[]
    temas?: string | string[]
    libroBiblico?: string
  }>
}

function normalizePage(value: string | undefined): number {
  const parsed = Number(value)
  if (!Number.isInteger(parsed) || parsed < 1) {
    return 1
  }
  return parsed
}

function normalizeSort(value: string | undefined): SortOrder {
  if (value === 'antiguo' || value === 'titulo') {
    return value
  }
  return 'reciente'
}

function normalizeArrayParam(value: string | string[] | undefined): string[] {
  if (!value) return []
  if (Array.isArray(value)) return value.filter(Boolean)
  return [value].filter(Boolean)
}

export default async function ArchivoPage({
  searchParams,
}: Readonly<ArchivoPageProps>) {
  const params = await searchParams
  const page = normalizePage(params.page)
  const sort = normalizeSort(params.sort)

  const filters: FilterState = {
    periodo: typeof params.periodo === 'string' ? params.periodo : null,
    formatos: normalizeArrayParam(params.formatos),
    temas: normalizeArrayParam(params.temas),
    libroBiblico:
      typeof params.libroBiblico === 'string' ? params.libroBiblico : null,
  }

  const { data: conferencias, total } = await getArchivoCronologicoPage({
    page,
    limit: PAGE_SIZE,
    sort,
    filters,
  })

  return (
    <ArchivoPageClient
      conferencias={conferencias}
      totalResults={total}
      page={page}
      pageSize={PAGE_SIZE}
      initialFilters={filters}
      initialSort={sort}
    />
  )
}
