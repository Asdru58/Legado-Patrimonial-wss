/**
 * Tipos TypeScript — Esquema Maestro Fase 5.6
 * Proyecto: Legado Patrimonial WSS
 *
 * Refactorizado: tabla multimedia eliminada.
 * Todos los campos de video/audio/PDF son planos en conferencias.
 */

// ============================================
// Proveedores y estados (espejo de CHECK constraints)
// ============================================

export type VideoProvider = 'none' | 'youtube' | 'r2' | 's3'
export type FallbackProvider = 'r2' | 's3'
export type VideoStatus =
  | 'pending'
  | 'active'
  | 'unavailable'
  | 'processing'
  | 'disabled'

// ============================================
// Entidad principal: conferencias (esquema plano)
// ============================================

export interface Conferencia {
  id: string
  slug: string
  titulo: string
  extracto: string | null
  descripcion: string | null
  fecha_impartida: string | null // ISO date (YYYY-MM-DD)
  ponente_nombre: string | null
  ponente_rol: string | null

  // Audio y PDF
  audio_url: string | null
  audio_duracion: number | null
  pdf_url: string | null

  // Video (modelo plano)
  video_provider: VideoProvider
  video_provider_id: string | null
  video_fallback_provider: FallbackProvider | null
  video_fallback_url: string | null
  video_status: VideoStatus
  video_checked_at: string | null

  // Timestamps
  created_at: string
  updated_at: string
}

// ============================================
// Entidades auxiliares (sin cambios)
// ============================================

export interface TranscripcionFragmento {
  id: string
  conferencia_id: string
  texto: string
  timestamp_start: number
  timestamp_end: number
  orden_secuencia: number
  embedding?: number[]
}

export interface GrafoTematico {
  id: string
  fragmento_id: string
  entidad: string
  created_at: string
}

// ============================================
// Tipos compuestos para la UI
// ============================================

/** Conferencia completa con transcripción */
export interface ConferenciaCompleta extends Conferencia {
  fragmentos: TranscripcionFragmento[]
}

/** Resultado de búsqueda semántica */
export interface ResultadoBusqueda {
  fragmento: TranscripcionFragmento
  conferencia: Conferencia
  similitud: number
}

// ============================================
// Helpers de detección de media
// ============================================

export function tieneAudio(conf: Conferencia): boolean {
  return Boolean(conf.audio_url)
}

export function tieneVideo(conf: Conferencia): boolean {
  return conf.video_provider !== 'none' && conf.video_status === 'active'
}

export function tienePdf(conf: Conferencia): boolean {
  return Boolean(conf.pdf_url)
}

// ============================================
// Estado del Reproductor
// ============================================

export interface EstadoReproductor {
  conferencia_activa: Conferencia | null
  esta_reproduciendo: boolean
  tiempo_actual: number
  duracion: number
  volumen: number
}
