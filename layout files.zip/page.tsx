// =========================================================
// Legado Patrimonial WSS — Fase 5.7
// src/app/admin/page.tsx
// Server Component: dashboard con métricas del archivo
// =========================================================

import { createClient } from '@/utils/supabase/server'

// Ruta autenticada: nunca cachear
export const dynamic = 'force-dynamic'

interface Metric {
  label: string
  value: string | number
  detail: string
}

export default async function AdminDashboard() {
  const supabase = await createClient()

  // ── Métricas desde la base de datos viva ──
  const [totalRes, activosRes, pendientesRes] = await Promise.all([
    supabase
      .from('conferencias')
      .select('*', { count: 'exact', head: true }),
    supabase
      .from('conferencias')
      .select('*', { count: 'exact', head: true })
      .eq('video_status', 'active'),
    supabase
      .from('conferencias')
      .select('*', { count: 'exact', head: true })
      .eq('video_status', 'pending'),
  ])

  const metrics: Metric[] = [
    {
      label: 'Total conferencias',
      value: totalRes.count ?? 0,
      detail: 'Registros en el archivo',
    },
    {
      label: 'Videos activos',
      value: activosRes.count ?? 0,
      detail: 'Disponibles para el público',
    },
    {
      label: 'Videos pendientes',
      value: pendientesRes.count ?? 0,
      detail: 'En espera de procesamiento',
    },
  ]

  return (
    <div>
      {/* ── Encabezado ── */}
      <header className="mb-10">
        <div className="inline-flex items-center gap-3 mb-4">
          <span className="block w-8 h-px bg-[#C8A843]/30" />
          <span
            className="
              font-[family-name:var(--font-dm-sans)]
              text-[10px] font-medium tracking-[0.3em] uppercase
              text-[#C8A843]/45
            "
          >
            Panel de control
          </span>
        </div>
        <h1
          className="
            font-[family-name:var(--font-cormorant)]
            text-3xl font-light text-white/90 tracking-wide
          "
        >
          Bienvenido al Archivo
        </h1>
        <p
          className="
            font-[family-name:var(--font-dm-sans)]
            text-sm text-white/25 mt-2
          "
        >
          Estado actual del acervo patrimonial.
        </p>
      </header>

      {/* ── Tarjetas de métricas ── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {metrics.map((metric) => (
          <div
            key={metric.label}
            className="
              border border-white/[0.06] bg-white/[0.015]
              rounded-sm p-6
              transition-all duration-300
              hover:border-white/[0.1] hover:bg-white/[0.025]
            "
          >
            <p
              className="
                font-[family-name:var(--font-dm-sans)]
                text-[10px] font-medium tracking-[0.2em] uppercase
                text-white/30 mb-3
              "
            >
              {metric.label}
            </p>
            <p
              className="
                font-[family-name:var(--font-cormorant)]
                text-4xl font-light text-[#C8A843]/80
                leading-none mb-2
              "
            >
              {metric.value}
            </p>
            <p
              className="
                font-[family-name:var(--font-dm-sans)]
                text-[11px] text-white/20
              "
            >
              {metric.detail}
            </p>
          </div>
        ))}
      </div>

      {/* ── Placeholder: acciones rápidas ── */}
      <div className="mt-10 border border-dashed border-white/[0.06] rounded-sm p-8 text-center">
        <p
          className="
            font-[family-name:var(--font-dm-sans)]
            text-xs text-white/15 tracking-wide
          "
        >
          El módulo CRUD de conferencias se construirá en la siguiente iteración.
        </p>
      </div>
    </div>
  )
}
