// =========================================================
// Legado Patrimonial WSS — Fase 5.7
// src/app/login/actions.ts
// Server Action: autenticación con Supabase Auth
// =========================================================

'use server'

import { redirect } from 'next/navigation'
import { createClient } from '@/utils/supabase/server'

export interface LoginState {
  error: string | null
}

export async function login(
  _prevState: LoginState | null,
  formData: FormData
): Promise<LoginState> {
  const supabase = await createClient()

  const email = formData.get('email') as string
  const password = formData.get('password') as string
  const redirectTo = formData.get('redirectTo') as string

  if (!email || !password) {
    return { error: 'Correo y contraseña son obligatorios.' }
  }

  const { error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  if (error) {
    // Mensaje genérico: no revelar si el email existe o no.
    return { error: 'Credenciales inválidas. Verifique sus datos.' }
  }

  // Validar redirectTo para prevenir open redirect attacks.
  // Solo se permiten rutas internas bajo /admin.
  const safePath =
    redirectTo && redirectTo.startsWith('/admin') ? redirectTo : '/admin'

  redirect(safePath)
}
