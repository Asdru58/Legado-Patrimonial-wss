// =========================================================
// Legado Patrimonial WSS — Fase 5.7
// src/app/admin/conferencias/nueva/page.tsx
// Server Component: vista de creación de conferencia
// =========================================================

import Link from 'next/link'
import { CrearConferenciaForm } from './crear-form'

export const dynamic = 'force-dynamic'

export default function NuevaConferenciaPage() {
  return (
    <div className="max-w-3xl">
      {/* ── Encabezado ── */}
      <header className="mb-8">
        <Link
          href="/admin/conferencias"
          className="
            inline-flex items-center gap-2 mb-5
            font-[family-name:var(--font-dm-sans)]
            text-sm text-white/50
            hover:text-[#C8A843]/80
            transition-colors duration-200
          "
        >
          <svg
            className="w-4 h-4"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={1.5}
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18"
            />
          </svg>
          Volver al inventario
        </Link>

        <div className="inline-flex items-center gap-3 mb-4">
          <span className="block w-8 h-px bg-[#C8A843]/40" />
          <span
            className="
              font-[family-name:var(--font-dm-sans)]
              text-xs font-medium tracking-[0.25em] uppercase
              text-[#C8A843]/70
            "
          >
            Nuevo registro
          </span>
        </div>

        <h1
          className="
            font-[family-name:var(--font-cormorant)]
            text-3xl font-light text-white/95 tracking-wide
          "
        >
          Registrar Conferencia
        </h1>
        <p
          className="
            font-[family-name:var(--font-dm-sans)]
            text-sm text-white/60 mt-1
          "
        >
          Completa los datos para incorporar una nueva pieza al archivo patrimonial.
        </p>
      </header>

      {/* ── Formulario ── */}
      <div
        className="
          border border-white/[0.06] bg-white/[0.01]
          rounded-sm p-8
        "
      >
        <CrearConferenciaForm />
      </div>
    </div>
  )
}
