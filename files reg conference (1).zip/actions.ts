// =========================================================
// Legado Patrimonial WSS — Fase 5.7
// src/app/admin/conferencias/nueva/actions.ts
// Server Action: insertar conferencia en Supabase
// =========================================================

'use server'

import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'

export interface CrearConferenciaState {
  error: string | null
  fieldErrors: Record<string, string>
}

const VIDEO_PROVIDERS = ['none', 'youtube', 'r2', 's3'] as const
const FALLBACK_PROVIDERS = ['r2', 's3'] as const
const VIDEO_STATUSES = [
  'pending',
  'active',
  'unavailable',
  'processing',
  'disabled',
] as const

const SLUG_REGEX = /^[a-z0-9]+(-[a-z0-9]+)*$/

export async function crearConferencia(
  _prevState: CrearConferenciaState | null,
  formData: FormData
): Promise<CrearConferenciaState> {
  const fieldErrors: Record<string, string> = {}

  // ── Extraer campos ──
  const titulo = (formData.get('titulo') as string)?.trim()
  const slug = (formData.get('slug') as string)?.trim()
  const fecha_impartida = (formData.get('fecha_impartida') as string)?.trim()
  const ponente_nombre =
    (formData.get('ponente_nombre') as string)?.trim() || null
  const ponente_rol =
    (formData.get('ponente_rol') as string)?.trim() || null
  const extracto = (formData.get('extracto') as string)?.trim() || null
  const descripcion = (formData.get('descripcion') as string)?.trim() || null

  const video_provider = formData.get('video_provider') as string
  const video_status = formData.get('video_status') as string
  const raw_provider_id =
    (formData.get('video_provider_id') as string)?.trim() || null
  const raw_fallback_provider =
    (formData.get('video_fallback_provider') as string)?.trim() || null
  const raw_fallback_url =
    (formData.get('video_fallback_url') as string)?.trim() || null

  // ── Validaciones obligatorias ──
  if (!titulo) {
    fieldErrors.titulo = 'El título es obligatorio.'
  }

  if (!slug) {
    fieldErrors.slug = 'El slug es obligatorio.'
  } else if (!SLUG_REGEX.test(slug)) {
    fieldErrors.slug =
      'Solo minúsculas, números y guiones (ej. mi-conferencia-2025).'
  }

  if (!fecha_impartida) {
    fieldErrors.fecha_impartida = 'La fecha es obligatoria.'
  }

  if (!VIDEO_PROVIDERS.includes(video_provider as any)) {
    fieldErrors.video_provider = 'Proveedor de video inválido.'
  }

  if (!VIDEO_STATUSES.includes(video_status as any)) {
    fieldErrors.video_status = 'Estado de video inválido.'
  }

  // ── Lógica de constraints de video ──

  // Constraint: provider_id obligatorio si provider ≠ 'none', nulo si = 'none'
  const video_provider_id =
    video_provider === 'none' ? null : raw_provider_id

  if (video_provider !== 'none' && !video_provider_id) {
    fieldErrors.video_provider_id =
      'El ID del proveedor es obligatorio cuando hay video.'
  }

  // Constraint: fallback como par consistente
  const fallback_provider_value =
    raw_fallback_provider === 'none' || !raw_fallback_provider
      ? null
      : raw_fallback_provider
  const fallback_url_value = raw_fallback_url || null

  let video_fallback_provider: string | null = null
  let video_fallback_url: string | null = null

  // Fallback no tiene sentido sin provider primario
  if (video_provider === 'none') {
    video_fallback_provider = null
    video_fallback_url = null
  } else {
    video_fallback_provider = fallback_provider_value
    video_fallback_url = fallback_url_value

    // Par consistente: ambos o ninguno
    if (video_fallback_provider && !video_fallback_url) {
      fieldErrors.video_fallback_url =
        'La URL de fallback es obligatoria si seleccionaste un proveedor.'
    }
    if (!video_fallback_provider && video_fallback_url) {
      fieldErrors.video_fallback_provider =
        'Selecciona un proveedor de fallback si proporcionas una URL.'
    }

    // Validar que sea un proveedor válido
    if (
      video_fallback_provider &&
      !FALLBACK_PROVIDERS.includes(video_fallback_provider as any)
    ) {
      fieldErrors.video_fallback_provider =
        'Proveedor de fallback inválido.'
    }
  }

  // ── Retornar errores si existen ──
  if (Object.keys(fieldErrors).length > 0) {
    return { error: 'Corrige los campos señalados.', fieldErrors }
  }

  // ── Insertar en Supabase ──
  const supabase = await createClient()

  const { error: dbError } = await supabase.from('conferencias').insert({
    titulo,
    slug,
    fecha_impartida,
    ponente_nombre,
    ponente_rol,
    extracto,
    descripcion,
    video_provider,
    video_provider_id,
    video_status,
    video_fallback_provider,
    video_fallback_url,
  })

  if (dbError) {
    // Slug duplicado
    if (dbError.code === '23505' && dbError.message.includes('slug')) {
      return {
        error: null,
        fieldErrors: {
          slug: 'Este slug ya existe. Elige uno diferente.',
        },
      }
    }
    return {
      error: `Error de base de datos: ${dbError.message}`,
      fieldErrors: {},
    }
  }

  redirect('/admin/conferencias')
}
